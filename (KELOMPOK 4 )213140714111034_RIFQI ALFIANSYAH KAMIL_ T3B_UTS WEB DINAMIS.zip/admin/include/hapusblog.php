<?php
    mysqli_query($koneksi, "DELETE FROM blog WHERE id_blog = '$_GET[id]' ");

    header("Location: index.php?include=blog&hapus=berhasil");
?>