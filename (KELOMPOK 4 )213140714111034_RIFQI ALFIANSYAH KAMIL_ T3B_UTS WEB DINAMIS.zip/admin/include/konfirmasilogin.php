<?php 
 if (isset($_POST['login'])) {
        $user = $_POST['username'];
        $pass = $_POST['password'];
        $username = mysqli_real_escape_string($koneksi, $user);
        $password = mysqli_real_escape_string($koneksi, MD5($pass));
        
        //cek username dan password
        $sql="select `id_user`, `levels` from `user` 
                where `username`='$username' and
               `password`='$password'";
        $query = mysqli_query($koneksi, $sql);
        $jumlah = mysqli_num_rows($query);
        if(empty($user)){
            $_SESSION["gagal"] = "userkosong";
            header("Location:index.php");
        }else if(empty($pass)){
            $_SESSION["gagal"] = "passkosong";
            header("Location:index.php");
        }else if($jumlah==0){
            $_SESSION["gagal"] = "userpasssalah";
            header("Location:index.php");
        }else{
            //get data
            while($data = mysqli_fetch_row($query)){
                $id_user = $data[0]; //1
                $level = $data[1]; //speradmin

                if ($level == "superadmin"){
                    $_SESSION['id_user']=$id_user;
                    $_SESSION['levels']="superadmin";
                }
                else if ($level == "admin"){
                $_SESSION['id_user']=$id_user;
                $_SESSION['levels']="admin";
                }
                header("Location:index.php?include=profil");
            }           
        }
    }



?>