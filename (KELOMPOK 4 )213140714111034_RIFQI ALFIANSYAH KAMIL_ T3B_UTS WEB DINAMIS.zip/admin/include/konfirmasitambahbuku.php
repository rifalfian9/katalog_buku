<?php
if (isset($_POST["tambah"])){
    if (empty($_POST["judul"])){
        header("Location: index.php?include=tambahbuku&tambah=gagal");
    }
    else{
        $lokasi_file = $_FILES['cover']['tmp_name'];
        $nama_file = $_FILES['cover']['name'];
        $direktori = 'cover/'.$nama_file;
        if (!empty($nama_file)) {
            move_uploaded_file($lokasi_file,$direktori);
            mysqli_query($koneksi, "INSERT INTO `buku` VALUES 
            ('','$_POST[pilihkb]',
            '$_POST[judul]',
            '$_POST[pengarang]',
            '$_POST[penerbit]', 
            '$_POST[tanggal]',
            '$_POST[sinopsis]', 
            '$nama_file' )");

            //mysqli_query($koneksi,"INSERT INTO `tag_buku` VALUES ('', '', '$_POST[pilihtag]')" );

            header("Location: index.php?include=buku&tambah=berhasil");
        }
        else {
             mysqli_query($koneksi, "INSERT INTO `buku` VALUES 
            ('','$_POST[pilihkb]',
            '$_POST[judul]',
            '$_POST[pengarang]',
            '$_POST[penerbit]', 
            '$_POST[tanggal]',
            '$_POST[sinopsis]' )");

            header("Location: index.php?include=buku&tambah=berhasil");
        }



    }


}

?>