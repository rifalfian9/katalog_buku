<?php
    mysqli_query($koneksi, "DELETE FROM buku WHERE id_buku = '$_GET[id]' ");

    header("Location: index.php?include=buku&hapus=berhasil");
?>