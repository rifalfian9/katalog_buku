<?php
    if (isset($_POST["submit"])){
        if (empty($_POST["judul"])) {
            header("Location: index.php?include=tambahblog&tambah=gagal");
        }
        else {
             
            $query = mysqli_query($koneksi,  "INSERT INTO `blog` (`id_blog` , `id_kategori_blog` , `id_user`, `tanggal`, `judul`, `isi` )
            VALUES ('', 
            '$_POST[pilih]',
            '60',
            '2004',
            '$_POST[judul]',
            '$_POST[isi]' )");
            
            header("Location: index.php?include=blog&tambah=berhasil");
        }
    }

?>