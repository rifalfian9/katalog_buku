<?php
 mysqli_query($koneksi, "DELETE FROM `kategori_blog` where id_kategori_blog = '$_GET[id]'");
 header("Location: index.php?include=kategoriblog&hapus=berhasil");





?>