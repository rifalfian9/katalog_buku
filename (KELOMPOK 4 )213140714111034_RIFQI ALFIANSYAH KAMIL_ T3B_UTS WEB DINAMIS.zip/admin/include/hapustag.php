<?php

mysqli_query($koneksi, "DELETE FROM `tag` WHERE `id_tag`='$_GET[id]'");
header("Location: index.php?include=tag&hapus=berhasil");


?>